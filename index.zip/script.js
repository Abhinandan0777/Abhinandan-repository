// Sample course data
const courses = [
    {
        title: "Web Development Bootcamp",
        image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=500",
        description: "Complete full-stack web development course",
        price: "Rs1999"
    },
    {
        title: "Graphic Design Masterclass",
        image: "https://images.unsplash.com/photo-1541462608143-67571c6738dd?auto=format&fit=crop&w=500",
        description: "Learn professional design tools and techniques",
        price: "Rs.3999"
    },
    {
        title: "Data Science Fundamentals",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=500",
        description: "Master data analysis and machine learning",
        price: "Rs.4999"
    },
    
    // Add more courses here
];

// Initialize courses
const coursesGrid = document.getElementById('coursesGrid');

function renderCourses(filteredCourses) {
    coursesGrid.innerHTML = filteredCourses.map(course => `
        <div class="col-md-4 mb-4">
            <div class="course-card">
                <img src="${course.image}" class="course-image" alt="${course.title}">
                <div class="course-content">
                    <h3 class="course-title">${course.title}</h3>
                    <p class="course-desc">${course.description}</p>
                    <div class="course-price">${course.price}</div>
                </div>
            </div>
        </div>
    `).join('');
}

// Search functionality
document.getElementById('searchInput').addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filtered = courses.filter(course =>
        course.title.toLowerCase().includes(searchTerm) ||
        course.description.toLowerCase().includes(searchTerm)
    );
    renderCourses(filtered);
});

// Initialize with all courses
renderCourses(courses);

// Set current year in footer
document.getElementById('currentYear').textContent = new Date().getFullYear();