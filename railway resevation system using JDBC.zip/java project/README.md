# Railway Reservation System

A Java Swing-based Railway Reservation System that allows users to book train tickets, manage reservations, and view booking history.

## Prerequisites

1. Java Development Kit (JDK) 8 or higher
2. SQL Server Management Studio (SSMS)
3. SQL Server JDBC Driver

## Setup Instructions

1. **Database Setup**
   - Open SQL Server Management Studio
   - Connect to your SQL Server instance
   - Open the `database.sql` file from `src/main/resources/`
   - Execute the script to create the database and tables

2. **Project Setup**
   - Make sure you have JDK installed
   - Download the SQL Server JDBC driver (mssql-jdbc-12.4.1.jre8.jar)
   - Add the JDBC driver to your project's classpath

3. **Database Connection**
   - Open `src/main/java/com/railway/reservation/util/DBConnection.java`
   - Update the connection details if needed:
     ```java
     private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=railway_reservation;encrypt=true;trustServerCertificate=true";
     private static final String USERNAME = "your_username";
     private static final String PASSWORD = "your_password";
     ```

## Running the Application

1. **Compile the Project**
   ```bash
   javac -cp ".;mssql-jdbc-12.4.1.jre8.jar" src/main/java/com/railway/reservation/*.java src/main/java/com/railway/reservation/*/*.java
   ```

2. **Run the Application**
   ```bash
   java -cp ".;mssql-jdbc-12.4.1.jre8.jar" com.railway.reservation.RailwayReservationSystem
   ```

## Features

1. User Registration and Login
2. Train Search
3. Seat Booking
4. Booking History
5. PNR Generation
6. Reservation Cancellation

## Default Users

1. Admin User:
   - Username: admin
   - Password: admin123

2. Test User:
   - Username: johndoe
   - Password: password123

## Troubleshooting

1. **Database Connection Issues**
   - Verify SQL Server is running
   - Check connection details in DBConnection.java
   - Ensure SQL Server authentication is enabled

2. **Compilation Issues**
   - Verify JDK installation
   - Check if JDBC driver is in classpath
   - Ensure all source files are in correct packages

3. **Runtime Issues**
   - Check database connection
   - Verify user credentials
   - Ensure all required tables exist 