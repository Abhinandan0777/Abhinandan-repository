#!/bin/bash

# Create bin directory if it doesn't exist
mkdir -p bin

# Compile
javac -cp "bin:lib/mssql-jdbc-12.10.0.jre11.jar" -d bin src/main/java/com/railway/reservation/RailwayReservationSystem.java src/main/java/com/railway/reservation/model/*.java src/main/java/com/railway/reservation/dao/*.java src/main/java/com/railway/reservation/util/*.java

# Run
java -cp "bin:lib/mssql-jdbc-12.10.0.jre11.jar" com.railway.reservation.RailwayReservationSystem 