import dao.*;
import model.*;

import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static User currentUser = null;

    public static void main(String[] args) {
        while (true) {
            if (currentUser == null) {
                System.out.println("\n--- Railway Reservation System ---");
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.println("0. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                switch (choice) {
                    case 1: register(); break;
                    case 2: login(); break;
                    case 0: System.exit(0);
                    default: System.out.println("Invalid option.");
                }
            } else {
                System.out.println("\n--- Main Menu ---");
                System.out.println("1. Train Management");
                System.out.println("2. Search Trains");
                System.out.println("3. Make Reservation");
                System.out.println("4. View Booking History");
                System.out.println("5. Cancel Reservation");
                System.out.println("6. Logout");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();
                switch (choice) {
                    case 1: trainManagement(); break;
                    case 2: searchTrains(); break;
                    case 3: makeReservation(); break;
                    case 4: viewBookingHistory(); break;
                    case 5: cancelReservation(); break;
                    case 6: currentUser = null; break;
                    default: System.out.println("Invalid option.");
                }
            }
        }
    }

    private static void register() {
        // TODO: Implement user registration
    }

    private static void login() {
        // TODO: Implement user login
    }

    private static void trainManagement() {
        // TODO: Implement train management (add/edit/delete)
    }

    private static void searchTrains() {
        // TODO: Implement train search
    }

    private static void makeReservation() {
        // TODO: Implement reservation
    }

    private static void viewBookingHistory() {
        // TODO: Implement booking history view
    }

    private static void cancelReservation() {
        // TODO: Implement reservation cancellation
    }
} 