package dao;

import model.PNR;
import util.DBConnection;

import java.sql.*;

public class PNRDAO {
    public boolean generatePNR(PNR pnr) {
        String sql = "INSERT INTO pnr_details (pnr_number, reservation_id, status, coach_number, seat_numbers, issued_at) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pnr.getPnrNumber());
            stmt.setInt(2, pnr.getReservationId());
            stmt.setString(3, pnr.getStatus());
            stmt.setString(4, pnr.getCoachNumber());
            stmt.setString(5, pnr.getSeatNumbers());
            stmt.setTimestamp(6, pnr.getIssuedAt());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public PNR getPNRByReservationId(int reservationId) {
        String sql = "SELECT * FROM pnr_details WHERE reservation_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new PNR(
                    rs.getString("pnr_number"),
                    rs.getInt("reservation_id"),
                    rs.getString("status"),
                    rs.getString("coach_number"),
                    rs.getString("seat_numbers"),
                    rs.getTimestamp("issued_at")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updatePNRStatus(String pnrNumber, String status) {
        String sql = "UPDATE pnr_details SET status = ? WHERE pnr_number = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setString(2, pnrNumber);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
} 