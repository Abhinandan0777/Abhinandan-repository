package dao;

import model.Reservation;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {
    public boolean makeReservation(Reservation reservation) {
        String sql = "INSERT INTO reservations (user_id, train_id, journey_date, travel_class, seats_booked, booking_timestamp, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, reservation.getUserId());
            stmt.setInt(2, reservation.getTrainId());
            stmt.setDate(3, reservation.getJourneyDate());
            stmt.setString(4, reservation.getTravelClass());
            stmt.setInt(5, reservation.getSeatsBooked());
            stmt.setTimestamp(6, reservation.getBookingTimestamp());
            stmt.setDouble(7, reservation.getTotalAmount());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    reservation.setReservationId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Reservation> getReservationsByUser(int userId) {
        String sql = "SELECT * FROM reservations WHERE user_id = ? ORDER BY booking_timestamp DESC";
        List<Reservation> reservations = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                reservations.add(new Reservation(
                    rs.getInt("reservation_id"),
                    rs.getInt("user_id"),
                    rs.getInt("train_id"),
                    rs.getDate("journey_date"),
                    rs.getString("travel_class"),
                    rs.getInt("seats_booked"),
                    rs.getTimestamp("booking_timestamp"),
                    rs.getDouble("total_amount")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservations;
    }

    public boolean cancelReservation(int reservationId) {
        String sql = "UPDATE pnr_details SET status = 'CANCELLED' WHERE reservation_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
} 