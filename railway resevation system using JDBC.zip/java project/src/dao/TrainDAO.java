package dao;

import model.Train;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrainDAO {
    public boolean addTrain(Train train) {
        String sql = "INSERT INTO trains (train_name, total_seats, boarding_station, destination_station, fare_ac_first, fare_ac_second, fare_ac_third, fare_sleeper, journey_date, departure_time, arrival_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, train.getTrainName());
            stmt.setInt(2, train.getTotalSeats());
            stmt.setString(3, train.getBoardingStation());
            stmt.setString(4, train.getDestinationStation());
            stmt.setDouble(5, train.getFareAcFirst());
            stmt.setDouble(6, train.getFareAcSecond());
            stmt.setDouble(7, train.getFareAcThird());
            stmt.setDouble(8, train.getFareSleeper());
            stmt.setDate(9, train.getJourneyDate());
            stmt.setTime(10, train.getDepartureTime());
            stmt.setTime(11, train.getArrivalTime());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateTrain(Train train) {
        String sql = "UPDATE trains SET train_name=?, total_seats=?, boarding_station=?, destination_station=?, fare_ac_first=?, fare_ac_second=?, fare_ac_third=?, fare_sleeper=?, journey_date=?, departure_time=?, arrival_time=? WHERE train_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, train.getTrainName());
            stmt.setInt(2, train.getTotalSeats());
            stmt.setString(3, train.getBoardingStation());
            stmt.setString(4, train.getDestinationStation());
            stmt.setDouble(5, train.getFareAcFirst());
            stmt.setDouble(6, train.getFareAcSecond());
            stmt.setDouble(7, train.getFareAcThird());
            stmt.setDouble(8, train.getFareSleeper());
            stmt.setDate(9, train.getJourneyDate());
            stmt.setTime(10, train.getDepartureTime());
            stmt.setTime(11, train.getArrivalTime());
            stmt.setInt(12, train.getTrainId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteTrain(int trainId) {
        String sql = "DELETE FROM trains WHERE train_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, trainId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Train> searchTrains(String boarding, String destination, Date journeyDate, String travelClass) {
        String sql = "SELECT * FROM trains WHERE boarding_station = ? AND destination_station = ? AND journey_date = ?";
        List<Train> trains = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, boarding);
            stmt.setString(2, destination);
            stmt.setDate(3, journeyDate);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                trains.add(new Train(
                    rs.getInt("train_id"),
                    rs.getString("train_name"),
                    rs.getInt("total_seats"),
                    rs.getString("boarding_station"),
                    rs.getString("destination_station"),
                    rs.getDouble("fare_ac_first"),
                    rs.getDouble("fare_ac_second"),
                    rs.getDouble("fare_ac_third"),
                    rs.getDouble("fare_sleeper"),
                    rs.getDate("journey_date"),
                    rs.getTime("departure_time"),
                    rs.getTime("arrival_time")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return trains;
    }
} 