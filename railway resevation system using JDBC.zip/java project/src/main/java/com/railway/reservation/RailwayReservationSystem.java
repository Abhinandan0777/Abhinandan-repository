package com.railway.reservation;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import com.railway.reservation.model.User;

public class RailwayReservationSystem extends JFrame {
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private User currentUser;
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color SECONDARY_COLOR = new Color(52, 152, 219);
    private static final Color BACKGROUND_COLOR = new Color(236, 240, 241);
    private static final Color TEXT_COLOR = new Color(44, 62, 80);
    private static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    private static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public RailwayReservationSystem() {
        setTitle("Railway Reservation System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setBackground(BACKGROUND_COLOR);

        // Set Nimbus Look and Feel
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            customizeNimbusLookAndFeel();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize components
        initializeComponents();
    }

    private void customizeNimbusLookAndFeel() {
        UIManager.put("Button.background", PRIMARY_COLOR);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.font", NORMAL_FONT);
        UIManager.put("TextField.background", Color.WHITE);
        UIManager.put("TextField.font", NORMAL_FONT);
        UIManager.put("Label.font", NORMAL_FONT);
        UIManager.put("Panel.background", BACKGROUND_COLOR);
    }

    private void initializeComponents() {
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBackground(BACKGROUND_COLOR);

        // Add different panels
        mainPanel.add(createLoginPanel(), "LOGIN");
        mainPanel.add(createRegisterPanel(), "REGISTER");
        mainPanel.add(createMainMenuPanel(), "MAIN_MENU");
        mainPanel.add(createSearchTrainsPanel(), "SEARCH_TRAINS");
        mainPanel.add(createBookingHistoryPanel(), "BOOKING_HISTORY");

        add(mainPanel);
        showLoginPanel();
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a container panel with white background
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBackground(Color.WHITE);
        containerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel titleLabel = new JLabel("Welcome Back!");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        containerPanel.add(titleLabel, gbc);

        // Username
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(5, 5, 5, 5);
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(NORMAL_FONT);
        containerPanel.add(usernameLabel, gbc);

        JTextField usernameField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(usernameField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(NORMAL_FONT);
        containerPanel.add(passwordLabel, gbc);

        JPasswordField passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        containerPanel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = createStyledButton("Login");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        containerPanel.add(loginButton, gbc);

        // Register Link
        JButton registerLink = new JButton("New User? Register here");
        registerLink.setBorderPainted(false);
        registerLink.setContentAreaFilled(false);
        registerLink.setForeground(PRIMARY_COLOR);
        registerLink.setFont(NORMAL_FONT);
        gbc.gridy = 4;
        containerPanel.add(registerLink, gbc);

        // Add action listeners
        loginButton.addActionListener(e -> {
            // TODO: Implement login logic
            showMainMenuPanel();
        });

        registerLink.addActionListener(e -> showRegisterPanel());

        // Add container panel to main panel
        panel.add(containerPanel);

        return panel;
    }

    private JPanel createRegisterPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a container panel with white background
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBackground(Color.WHITE);
        containerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        containerPanel.add(titleLabel, gbc);

        // Full Name
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(5, 5, 5, 5);
        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameLabel.setFont(NORMAL_FONT);
        containerPanel.add(fullNameLabel, gbc);

        JTextField fullNameField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(fullNameField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(NORMAL_FONT);
        containerPanel.add(emailLabel, gbc);

        JTextField emailField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(emailField, gbc);

        // Username
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(NORMAL_FONT);
        containerPanel.add(usernameLabel, gbc);

        JTextField usernameField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(usernameField, gbc);

        // Password
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(NORMAL_FONT);
        containerPanel.add(passwordLabel, gbc);

        JPasswordField passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        containerPanel.add(passwordField, gbc);

        // Age
        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setFont(NORMAL_FONT);
        containerPanel.add(ageLabel, gbc);

        JSpinner ageSpinner = new JSpinner(new SpinnerNumberModel(18, 5, 120, 1));
        gbc.gridx = 1;
        containerPanel.add(ageSpinner, gbc);

        // Gender
        gbc.gridx = 0;
        gbc.gridy = 6;
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setFont(NORMAL_FONT);
        containerPanel.add(genderLabel, gbc);

        String[] genders = {"Male", "Female", "Other"};
        JComboBox<String> genderCombo = new JComboBox<>(genders);
        gbc.gridx = 1;
        containerPanel.add(genderCombo, gbc);

        // Register Button
        JButton registerButton = createStyledButton("Register");
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        containerPanel.add(registerButton, gbc);

        // Login Link
        JButton loginLink = new JButton("Already have an account? Login here");
        loginLink.setBorderPainted(false);
        loginLink.setContentAreaFilled(false);
        loginLink.setForeground(PRIMARY_COLOR);
        loginLink.setFont(NORMAL_FONT);
        gbc.gridy = 8;
        containerPanel.add(loginLink, gbc);

        // Add action listeners
        registerButton.addActionListener(e -> {
            // TODO: Implement registration logic
            showLoginPanel();
        });

        loginLink.addActionListener(e -> showLoginPanel());

        // Add container panel to main panel
        panel.add(containerPanel);

        return panel;
    }

    private JPanel createMainMenuPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a container panel with white background
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBackground(Color.WHITE);
        containerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel titleLabel = new JLabel("Main Menu");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        containerPanel.add(titleLabel, gbc);

        // Menu Buttons
        JButton searchButton = createStyledButton("Search Trains");
        JButton historyButton = createStyledButton("Booking History");
        JButton logoutButton = createStyledButton("Logout");

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 5, 10, 5);
        containerPanel.add(searchButton, gbc);

        gbc.gridy = 2;
        containerPanel.add(historyButton, gbc);

        gbc.gridy = 3;
        containerPanel.add(logoutButton, gbc);

        // Add action listeners
        searchButton.addActionListener(e -> showSearchTrainsPanel());
        historyButton.addActionListener(e -> showBookingHistoryPanel());
        logoutButton.addActionListener(e -> showLoginPanel());

        // Add container panel to main panel
        panel.add(containerPanel);

        return panel;
    }

    private JPanel createSearchTrainsPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a container panel with white background
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBackground(Color.WHITE);
        containerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel titleLabel = new JLabel("Search Trains");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        containerPanel.add(titleLabel, gbc);

        // Search Fields
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel fromLabel = new JLabel("From:");
        fromLabel.setFont(NORMAL_FONT);
        containerPanel.add(fromLabel, gbc);

        JTextField fromField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(fromField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel toLabel = new JLabel("To:");
        toLabel.setFont(NORMAL_FONT);
        containerPanel.add(toLabel, gbc);

        JTextField toField = new JTextField(20);
        gbc.gridx = 1;
        containerPanel.add(toField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setFont(NORMAL_FONT);
        containerPanel.add(dateLabel, gbc);

        SpinnerDateModel dateModel = new SpinnerDateModel(new Date(), null, null, java.util.Calendar.DAY_OF_MONTH);
        JSpinner dateSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);
        gbc.gridx = 1;
        containerPanel.add(dateSpinner, gbc);

        // Search Button
        JButton searchButton = createStyledButton("Search");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        containerPanel.add(searchButton, gbc);

        // Back Button
        JButton backButton = createStyledButton("Back to Main Menu");
        gbc.gridy = 5;
        containerPanel.add(backButton, gbc);

        // Add action listeners
        searchButton.addActionListener(e -> {
            // TODO: Implement search logic
        });

        backButton.addActionListener(e -> showMainMenuPanel());

        // Add container panel to main panel
        panel.add(containerPanel);

        return panel;
    }

    private JPanel createBookingHistoryPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create a container panel with white background
        JPanel containerPanel = new JPanel(new GridBagLayout());
        containerPanel.setBackground(Color.WHITE);
        containerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel titleLabel = new JLabel("Booking History");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        containerPanel.add(titleLabel, gbc);

        // Table
        String[] columnNames = {"PNR", "Train", "Date", "Class", "Status", "Amount"};
        Object[][] data = {}; // TODO: Add actual booking data
        JTable bookingTable = new JTable(data, columnNames);
        bookingTable.setFont(NORMAL_FONT);
        bookingTable.setRowHeight(25);
        bookingTable.getTableHeader().setFont(HEADER_FONT);
        
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        scrollPane.setPreferredSize(new Dimension(800, 400));
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        containerPanel.add(scrollPane, gbc);

        // Back Button
        JButton backButton = createStyledButton("Back to Main Menu");
        gbc.gridy = 2;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(20, 5, 5, 5);
        containerPanel.add(backButton, gbc);

        backButton.addActionListener(e -> showMainMenuPanel());

        // Add container panel to main panel
        panel.add(containerPanel);

        return panel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(NORMAL_FONT);
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(200, 40));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(SECONDARY_COLOR);
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(PRIMARY_COLOR);
            }
        });
        
        return button;
    }

    private void showLoginPanel() {
        cardLayout.show(mainPanel, "LOGIN");
    }

    private void showRegisterPanel() {
        cardLayout.show(mainPanel, "REGISTER");
    }

    private void showMainMenuPanel() {
        cardLayout.show(mainPanel, "MAIN_MENU");
    }

    private void showSearchTrainsPanel() {
        cardLayout.show(mainPanel, "SEARCH_TRAINS");
    }

    private void showBookingHistoryPanel() {
        cardLayout.show(mainPanel, "BOOKING_HISTORY");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new RailwayReservationSystem().setVisible(true);
        });
    }
} 