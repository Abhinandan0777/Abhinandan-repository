package com.railway.reservation.dao;

import com.railway.reservation.model.PNR;
import com.railway.reservation.util.DBConnection;

import java.sql.*;
import java.util.Random;

public class PNRDAO {
    public String generatePNR() {
        // Generate a random 10-digit PNR number
        Random random = new Random();
        StringBuilder pnr = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            pnr.append(random.nextInt(10));
        }
        return pnr.toString();
    }

    public boolean createPNR(PNR pnr) {
        String query = "INSERT INTO pnr_details (pnr_number, reservation_id, status, coach_number, " +
                      "seat_numbers, issued_at) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, pnr.getPnrNumber());
            pstmt.setLong(2, pnr.getReservation().getReservationId());
            pstmt.setString(3, pnr.getStatus().name());
            pstmt.setString(4, pnr.getCoachNumber());
            pstmt.setString(5, pnr.getSeatNumbers());
            pstmt.setTimestamp(6, Timestamp.valueOf(pnr.getIssuedAt()));
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public PNR getPNRByNumber(String pnrNumber) {
        String query = "SELECT p.*, r.*, t.*, u.* FROM pnr_details p " +
                      "JOIN reservations r ON p.reservation_id = r.reservation_id " +
                      "JOIN trains t ON r.train_id = t.train_id " +
                      "JOIN users u ON r.user_id = u.user_id " +
                      "WHERE p.pnr_number = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, pnrNumber);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    PNR pnr = new PNR();
                    pnr.setPnrNumber(rs.getString("pnr_number"));
                    pnr.setStatus(PNR.Status.valueOf(rs.getString("status")));
                    pnr.setCoachNumber(rs.getString("coach_number"));
                    pnr.setSeatNumbers(rs.getString("seat_numbers"));
                    pnr.setIssuedAt(rs.getTimestamp("issued_at").toLocalDateTime());
                    
                    // Set reservation details
                    pnr.getReservation().setReservationId(rs.getLong("reservation_id"));
                    pnr.getReservation().setJourneyDate(rs.getDate("journey_date").toLocalDate());
                    pnr.getReservation().setTravelClass(com.railway.reservation.model.Reservation.TravelClass.valueOf(rs.getString("travel_class")));
                    pnr.getReservation().setSeatsBooked(rs.getInt("seats_booked"));
                    pnr.getReservation().setBookingTimestamp(rs.getTimestamp("booking_timestamp").toLocalDateTime());
                    pnr.getReservation().setTotalAmount(rs.getDouble("total_amount"));
                    
                    // Set train details
                    pnr.getReservation().getTrain().setTrainId(rs.getLong("train_id"));
                    pnr.getReservation().getTrain().setTrainName(rs.getString("train_name"));
                    pnr.getReservation().getTrain().setBoardingStation(rs.getString("boarding_station"));
                    pnr.getReservation().getTrain().setDestinationStation(rs.getString("destination_station"));
                    pnr.getReservation().getTrain().setDepartureTime(rs.getTime("departure_time").toLocalTime());
                    pnr.getReservation().getTrain().setArrivalTime(rs.getTime("arrival_time").toLocalTime());
                    
                    // Set user details
                    pnr.getReservation().getUser().setUserId(rs.getLong("user_id"));
                    pnr.getReservation().getUser().setFullName(rs.getString("full_name"));
                    pnr.getReservation().getUser().setEmail(rs.getString("email"));
                    
                    return pnr;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updatePNRStatus(String pnrNumber, PNR.Status status) {
        String query = "UPDATE pnr_details SET status = ? WHERE pnr_number = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, status.name());
            pstmt.setString(2, pnrNumber);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
} 