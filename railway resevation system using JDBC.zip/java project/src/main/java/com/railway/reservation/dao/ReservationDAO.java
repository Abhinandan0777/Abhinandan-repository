package com.railway.reservation.dao;

import com.railway.reservation.model.Reservation;
import com.railway.reservation.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {
    public boolean makeReservation(Reservation reservation) {
        String query = "INSERT INTO reservations (user_id, train_id, journey_date, travel_class, " +
                      "seats_booked, booking_timestamp, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setLong(1, reservation.getUser().getUserId());
            pstmt.setLong(2, reservation.getTrain().getTrainId());
            pstmt.setDate(3, Date.valueOf(reservation.getJourneyDate()));
            pstmt.setString(4, reservation.getTravelClass().name());
            pstmt.setInt(5, reservation.getSeatsBooked());
            pstmt.setTimestamp(6, Timestamp.valueOf(reservation.getBookingTimestamp()));
            pstmt.setDouble(7, reservation.getTotalAmount());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        reservation.setReservationId(rs.getLong(1));
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Reservation> getReservationsByUser(Long userId) {
        List<Reservation> reservations = new ArrayList<>();
        String query = "SELECT r.*, t.*, u.* FROM reservations r " +
                      "JOIN trains t ON r.train_id = t.train_id " +
                      "JOIN users u ON r.user_id = u.user_id " +
                      "WHERE r.user_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setLong(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Reservation reservation = new Reservation();
                    reservation.setReservationId(rs.getLong("reservation_id"));
                    reservation.setJourneyDate(rs.getDate("journey_date").toLocalDate());
                    reservation.setTravelClass(Reservation.TravelClass.valueOf(rs.getString("travel_class")));
                    reservation.setSeatsBooked(rs.getInt("seats_booked"));
                    reservation.setBookingTimestamp(rs.getTimestamp("booking_timestamp").toLocalDateTime());
                    reservation.setTotalAmount(rs.getDouble("total_amount"));
                    
                    // Set train details
                    reservation.getTrain().setTrainId(rs.getLong("train_id"));
                    reservation.getTrain().setTrainName(rs.getString("train_name"));
                    reservation.getTrain().setBoardingStation(rs.getString("boarding_station"));
                    reservation.getTrain().setDestinationStation(rs.getString("destination_station"));
                    reservation.getTrain().setDepartureTime(rs.getTime("departure_time").toLocalTime());
                    reservation.getTrain().setArrivalTime(rs.getTime("arrival_time").toLocalTime());
                    
                    // Set user details
                    reservation.getUser().setUserId(rs.getLong("user_id"));
                    reservation.getUser().setFullName(rs.getString("full_name"));
                    reservation.getUser().setEmail(rs.getString("email"));
                    
                    reservations.add(reservation);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservations;
    }

    public boolean cancelReservation(Long reservationId) {
        String query = "DELETE FROM reservations WHERE reservation_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setLong(1, reservationId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Reservation getReservationById(Long reservationId) {
        String query = "SELECT r.*, t.*, u.* FROM reservations r " +
                      "JOIN trains t ON r.train_id = t.train_id " +
                      "JOIN users u ON r.user_id = u.user_id " +
                      "WHERE r.reservation_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setLong(1, reservationId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Reservation reservation = new Reservation();
                    reservation.setReservationId(rs.getLong("reservation_id"));
                    reservation.setJourneyDate(rs.getDate("journey_date").toLocalDate());
                    reservation.setTravelClass(Reservation.TravelClass.valueOf(rs.getString("travel_class")));
                    reservation.setSeatsBooked(rs.getInt("seats_booked"));
                    reservation.setBookingTimestamp(rs.getTimestamp("booking_timestamp").toLocalDateTime());
                    reservation.setTotalAmount(rs.getDouble("total_amount"));
                    
                    // Set train details
                    reservation.getTrain().setTrainId(rs.getLong("train_id"));
                    reservation.getTrain().setTrainName(rs.getString("train_name"));
                    reservation.getTrain().setBoardingStation(rs.getString("boarding_station"));
                    reservation.getTrain().setDestinationStation(rs.getString("destination_station"));
                    reservation.getTrain().setDepartureTime(rs.getTime("departure_time").toLocalTime());
                    reservation.getTrain().setArrivalTime(rs.getTime("arrival_time").toLocalTime());
                    
                    // Set user details
                    reservation.getUser().setUserId(rs.getLong("user_id"));
                    reservation.getUser().setFullName(rs.getString("full_name"));
                    reservation.getUser().setEmail(rs.getString("email"));
                    
                    return reservation;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
} 