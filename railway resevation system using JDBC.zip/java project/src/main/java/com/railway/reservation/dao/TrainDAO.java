package com.railway.reservation.dao;

import com.railway.reservation.model.Train;
import com.railway.reservation.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TrainDAO {
    public boolean addTrain(Train train) {
        String query = "INSERT INTO trains (train_name, total_seats, boarding_station, destination_station, " +
                      "fare_ac_first, fare_ac_second, fare_ac_third, fare_sleeper, journey_date, " +
                      "departure_time, arrival_time, available_seats) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, train.getTrainName());
            pstmt.setInt(2, train.getTotalSeats());
            pstmt.setString(3, train.getBoardingStation());
            pstmt.setString(4, train.getDestinationStation());
            pstmt.setDouble(5, train.getFareAcFirst());
            pstmt.setDouble(6, train.getFareAcSecond());
            pstmt.setDouble(7, train.getFareAcThird());
            pstmt.setDouble(8, train.getFareSleeper());
            pstmt.setDate(9, Date.valueOf(train.getJourneyDate()));
            pstmt.setTime(10, Time.valueOf(train.getDepartureTime()));
            pstmt.setTime(11, Time.valueOf(train.getArrivalTime()));
            pstmt.setInt(12, train.getAvailableSeats());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Train> searchTrains(String from, String to, LocalDate date) {
        List<Train> trains = new ArrayList<>();
        String query = "SELECT * FROM trains WHERE boarding_station = ? AND destination_station = ? AND journey_date = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, from);
            pstmt.setString(2, to);
            pstmt.setDate(3, Date.valueOf(date));
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Train train = new Train();
                    train.setTrainId(rs.getLong("train_id"));
                    train.setTrainName(rs.getString("train_name"));
                    train.setTotalSeats(rs.getInt("total_seats"));
                    train.setBoardingStation(rs.getString("boarding_station"));
                    train.setDestinationStation(rs.getString("destination_station"));
                    train.setFareAcFirst(rs.getDouble("fare_ac_first"));
                    train.setFareAcSecond(rs.getDouble("fare_ac_second"));
                    train.setFareAcThird(rs.getDouble("fare_ac_third"));
                    train.setFareSleeper(rs.getDouble("fare_sleeper"));
                    train.setJourneyDate(rs.getDate("journey_date").toLocalDate());
                    train.setDepartureTime(rs.getTime("departure_time").toLocalTime());
                    train.setArrivalTime(rs.getTime("arrival_time").toLocalTime());
                    train.setAvailableSeats(rs.getInt("available_seats"));
                    trains.add(train);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return trains;
    }

    public Train getTrainById(Long trainId) {
        String query = "SELECT * FROM trains WHERE train_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setLong(1, trainId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Train train = new Train();
                    train.setTrainId(rs.getLong("train_id"));
                    train.setTrainName(rs.getString("train_name"));
                    train.setTotalSeats(rs.getInt("total_seats"));
                    train.setBoardingStation(rs.getString("boarding_station"));
                    train.setDestinationStation(rs.getString("destination_station"));
                    train.setFareAcFirst(rs.getDouble("fare_ac_first"));
                    train.setFareAcSecond(rs.getDouble("fare_ac_second"));
                    train.setFareAcThird(rs.getDouble("fare_ac_third"));
                    train.setFareSleeper(rs.getDouble("fare_sleeper"));
                    train.setJourneyDate(rs.getDate("journey_date").toLocalDate());
                    train.setDepartureTime(rs.getTime("departure_time").toLocalTime());
                    train.setArrivalTime(rs.getTime("arrival_time").toLocalTime());
                    train.setAvailableSeats(rs.getInt("available_seats"));
                    return train;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateAvailableSeats(Long trainId, int seatsBooked) {
        String query = "UPDATE trains SET available_seats = available_seats - ? WHERE train_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, seatsBooked);
            pstmt.setLong(2, trainId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
} 