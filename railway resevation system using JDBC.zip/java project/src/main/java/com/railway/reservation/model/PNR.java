package com.railway.reservation.model;

import java.time.LocalDateTime;

public class PNR {
    private String pnrNumber;
    private Reservation reservation;
    private Status status;
    private String coachNumber;
    private String seatNumbers;
    private LocalDateTime issuedAt;

    public PNR() {
        this.issuedAt = LocalDateTime.now();
    }

    public PNR(String pnrNumber, Reservation reservation, Status status, String coachNumber, String seatNumbers) {
        this.pnrNumber = pnrNumber;
        this.reservation = reservation;
        this.status = status;
        this.coachNumber = coachNumber;
        this.seatNumbers = seatNumbers;
        this.issuedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getPnrNumber() {
        return pnrNumber;
    }

    public void setPnrNumber(String pnrNumber) {
        this.pnrNumber = pnrNumber;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getCoachNumber() {
        return coachNumber;
    }

    public void setCoachNumber(String coachNumber) {
        this.coachNumber = coachNumber;
    }

    public String getSeatNumbers() {
        return seatNumbers;
    }

    public void setSeatNumbers(String seatNumbers) {
        this.seatNumbers = seatNumbers;
    }

    public LocalDateTime getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(LocalDateTime issuedAt) {
        this.issuedAt = issuedAt;
    }

    public enum Status {
        CONFIRMED, WAITLISTED, CANCELLED
    }
} 