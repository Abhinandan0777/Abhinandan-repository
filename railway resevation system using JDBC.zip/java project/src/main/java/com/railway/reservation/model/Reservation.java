package com.railway.reservation.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Reservation {
    private Long reservationId;
    private User user;
    private Train train;
    private LocalDate journeyDate;
    private TravelClass travelClass;
    private int seatsBooked;
    private LocalDateTime bookingTimestamp;
    private double totalAmount;

    public Reservation() {
        this.bookingTimestamp = LocalDateTime.now();
    }

    public Reservation(User user, Train train, LocalDate journeyDate, TravelClass travelClass, int seatsBooked) {
        this.user = user;
        this.train = train;
        this.journeyDate = journeyDate;
        this.travelClass = travelClass;
        this.seatsBooked = seatsBooked;
        this.bookingTimestamp = LocalDateTime.now();
        this.totalAmount = train.getFareForClass(travelClass.name()) * seatsBooked;
    }

    // Getters and Setters
    public Long getReservationId() {
        return reservationId;
    }

    public void setReservationId(Long reservationId) {
        this.reservationId = reservationId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Train getTrain() {
        return train;
    }

    public void setTrain(Train train) {
        this.train = train;
    }

    public LocalDate getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(LocalDate journeyDate) {
        this.journeyDate = journeyDate;
    }

    public TravelClass getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(TravelClass travelClass) {
        this.travelClass = travelClass;
    }

    public int getSeatsBooked() {
        return seatsBooked;
    }

    public void setSeatsBooked(int seatsBooked) {
        this.seatsBooked = seatsBooked;
    }

    public LocalDateTime getBookingTimestamp() {
        return bookingTimestamp;
    }

    public void setBookingTimestamp(LocalDateTime bookingTimestamp) {
        this.bookingTimestamp = bookingTimestamp;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public enum TravelClass {
        AC1, AC2, AC3, SLEEPER
    }
} 