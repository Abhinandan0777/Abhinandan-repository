package com.railway.reservation.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Train {
    private Long trainId;
    private String trainName;
    private int totalSeats;
    private String boardingStation;
    private String destinationStation;
    private double fareAcFirst;
    private double fareAcSecond;
    private double fareAcThird;
    private double fareSleeper;
    private LocalDate journeyDate;
    private LocalTime departureTime;
    private LocalTime arrivalTime;
    private int availableSeats;

    public Train() {
    }

    public Train(String trainName, int totalSeats, String boardingStation, String destinationStation,
                double fareAcFirst, double fareAcSecond, double fareAcThird, double fareSleeper,
                LocalDate journeyDate, LocalTime departureTime, LocalTime arrivalTime) {
        this.trainName = trainName;
        this.totalSeats = totalSeats;
        this.boardingStation = boardingStation;
        this.destinationStation = destinationStation;
        this.fareAcFirst = fareAcFirst;
        this.fareAcSecond = fareAcSecond;
        this.fareAcThird = fareAcThird;
        this.fareSleeper = fareSleeper;
        this.journeyDate = journeyDate;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.availableSeats = totalSeats;
    }

    public double getFareForClass(String travelClass) {
        return switch (travelClass) {
            case "AC1" -> fareAcFirst;
            case "AC2" -> fareAcSecond;
            case "AC3" -> fareAcThird;
            case "SLEEPER" -> fareSleeper;
            default -> 0.0;
        };
    }

    // Getters and Setters
    public Long getTrainId() {
        return trainId;
    }

    public void setTrainId(Long trainId) {
        this.trainId = trainId;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public void setTotalSeats(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    public String getBoardingStation() {
        return boardingStation;
    }

    public void setBoardingStation(String boardingStation) {
        this.boardingStation = boardingStation;
    }

    public String getDestinationStation() {
        return destinationStation;
    }

    public void setDestinationStation(String destinationStation) {
        this.destinationStation = destinationStation;
    }

    public double getFareAcFirst() {
        return fareAcFirst;
    }

    public void setFareAcFirst(double fareAcFirst) {
        this.fareAcFirst = fareAcFirst;
    }

    public double getFareAcSecond() {
        return fareAcSecond;
    }

    public void setFareAcSecond(double fareAcSecond) {
        this.fareAcSecond = fareAcSecond;
    }

    public double getFareAcThird() {
        return fareAcThird;
    }

    public void setFareAcThird(double fareAcThird) {
        this.fareAcThird = fareAcThird;
    }

    public double getFareSleeper() {
        return fareSleeper;
    }

    public void setFareSleeper(double fareSleeper) {
        this.fareSleeper = fareSleeper;
    }

    public LocalDate getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(LocalDate journeyDate) {
        this.journeyDate = journeyDate;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = departureTime;
    }

    public LocalTime getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(LocalTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
} 