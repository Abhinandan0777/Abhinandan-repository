-- Create database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'railway_reservation')
BEGIN
    CREATE DATABASE railway_reservation;
END
GO

USE railway_reservation;
GO

-- Create users table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'users')
BEGIN
    CREATE TABLE users (
        user_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        full_name NVARCHAR(100) NOT NULL,
        email NVARCHAR(100) NOT NULL UNIQUE,
        username NVARCHAR(50) NOT NULL UNIQUE,
        password NVARCHAR(100) NOT NULL,
        age INT NOT NULL,
        gender NVARCHAR(10) NOT NULL CHECK (gender IN ('MALE', 'FEMALE', 'OTHER')),
        created_at DATETIME2 NOT NULL DEFAULT GETDATE()
    );
END
GO

-- Create trains table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'trains')
BEGIN
    CREATE TABLE trains (
        train_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        train_name NVARCHAR(100) NOT NULL,
        total_seats INT NOT NULL,
        boarding_station NVARCHAR(100) NOT NULL,
        destination_station NVARCHAR(100) NOT NULL,
        fare_ac_first DECIMAL(10,2) NOT NULL,
        fare_ac_second DECIMAL(10,2) NOT NULL,
        fare_ac_third DECIMAL(10,2) NOT NULL,
        fare_sleeper DECIMAL(10,2) NOT NULL,
        journey_date DATE NOT NULL,
        departure_time TIME NOT NULL,
        arrival_time TIME NOT NULL,
        available_seats INT NOT NULL
    );
END
GO

-- Create reservations table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'reservations')
BEGIN
    CREATE TABLE reservations (
        reservation_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        user_id BIGINT NOT NULL,
        train_id BIGINT NOT NULL,
        journey_date DATE NOT NULL,
        travel_class NVARCHAR(10) NOT NULL CHECK (travel_class IN ('AC1', 'AC2', 'AC3', 'SLEEPER')),
        seats_booked INT NOT NULL,
        booking_timestamp DATETIME2 NOT NULL DEFAULT GETDATE(),
        total_amount DECIMAL(10,2) NOT NULL,
        CONSTRAINT FK_Reservation_User FOREIGN KEY (user_id) REFERENCES users(user_id),
        CONSTRAINT FK_Reservation_Train FOREIGN KEY (train_id) REFERENCES trains(train_id)
    );
END
GO

-- Create pnr_details table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'pnr_details')
BEGIN
    CREATE TABLE pnr_details (
        pnr_number NVARCHAR(10) PRIMARY KEY,
        reservation_id BIGINT NOT NULL,
        status NVARCHAR(10) NOT NULL CHECK (status IN ('CONFIRMED', 'WAITLISTED', 'CANCELLED')),
        coach_number NVARCHAR(10) NOT NULL,
        seat_numbers NVARCHAR(100) NOT NULL,
        issued_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_PNR_Reservation FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id)
    );
END
GO

-- Insert sample users
IF NOT EXISTS (SELECT * FROM users)
BEGIN
    INSERT INTO users (full_name, email, username, password, age, gender, created_at) VALUES
    ('John Doe', 'john.doe@email.com', 'johndoe', 'password123', 25, 'MALE', GETDATE()),
    ('Jane Smith', 'jane.smith@email.com', 'janesmith', 'password456', 30, 'FEMALE', GETDATE()),
    ('Admin User', 'admin@railway.com', 'admin', 'admin123', 35, 'MALE', GETDATE());
END
GO

-- Insert sample trains
IF NOT EXISTS (SELECT * FROM trains)
BEGIN
    INSERT INTO trains (train_name, total_seats, boarding_station, destination_station, 
                       fare_ac_first, fare_ac_second, fare_ac_third, fare_sleeper,
                       journey_date, departure_time, arrival_time, available_seats) VALUES
    ('Rajdhani Express', 500, 'New Delhi', 'Mumbai Central', 4500.00, 2500.00, 1500.00, 800.00, 
     CAST(GETDATE() AS DATE), '16:55:00', '08:35:00', 500),
    ('Duronto Express', 400, 'Howrah', 'New Delhi', 4000.00, 2200.00, 1300.00, 700.00,
     CAST(GETDATE() AS DATE), '23:00:00', '16:55:00', 400),
    ('Shatabdi Express', 300, 'Chennai Central', 'Bangalore City', 2000.00, 1200.00, 800.00, 500.00,
     CAST(GETDATE() AS DATE), '06:00:00', '13:00:00', 300);
END
GO

-- Insert sample reservations
IF NOT EXISTS (SELECT * FROM reservations)
BEGIN
    INSERT INTO reservations (user_id, train_id, journey_date, travel_class, seats_booked, booking_timestamp, total_amount) VALUES
    (1, 1, CAST(GETDATE() AS DATE), 'AC1', 2, GETDATE(), 9000.00),
    (2, 2, CAST(GETDATE() AS DATE), 'AC2', 1, GETDATE(), 2200.00),
    (3, 3, CAST(GETDATE() AS DATE), 'SLEEPER', 3, GETDATE(), 1500.00);
END
GO

-- Insert sample PNR details
IF NOT EXISTS (SELECT * FROM pnr_details)
BEGIN
    INSERT INTO pnr_details (pnr_number, reservation_id, status, coach_number, seat_numbers, issued_at) VALUES
    ('1234567890', 1, 'CONFIRMED', 'A1', '1,2', GETDATE()),
    ('2345678901', 2, 'CONFIRMED', 'B2', '15', GETDATE()),
    ('3456789012', 3, 'CONFIRMED', 'S3', '45,46,47', GETDATE());
END
GO

-- Create useful views
IF NOT EXISTS (SELECT * FROM sys.views WHERE name = 'vw_booking_details')
BEGIN
    CREATE VIEW vw_booking_details AS
    SELECT 
        p.pnr_number,
        u.full_name,
        u.email,
        t.train_name,
        t.boarding_station,
        t.destination_station,
        r.journey_date,
        r.travel_class,
        r.seats_booked,
        r.total_amount,
        p.status,
        p.coach_number,
        p.seat_numbers,
        p.issued_at
    FROM pnr_details p
    JOIN reservations r ON p.reservation_id = r.reservation_id
    JOIN users u ON r.user_id = u.user_id
    JOIN trains t ON r.train_id = t.train_id;
END
GO

-- Create stored procedures
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_search_trains')
BEGIN
    CREATE PROCEDURE sp_search_trains
        @from_station NVARCHAR(100),
        @to_station NVARCHAR(100),
        @journey_date DATE
    AS
    BEGIN
        SELECT 
            train_id,
            train_name,
            boarding_station,
            destination_station,
            fare_ac_first,
            fare_ac_second,
            fare_ac_third,
            fare_sleeper,
            journey_date,
            departure_time,
            arrival_time,
            available_seats
        FROM trains
        WHERE boarding_station = @from_station
        AND destination_station = @to_station
        AND journey_date = @journey_date
        AND available_seats > 0;
    END
END
GO

-- Create function to calculate fare
IF NOT EXISTS (SELECT * FROM sys.objects WHERE name = 'fn_calculate_fare')
BEGIN
    CREATE FUNCTION fn_calculate_fare
    (
        @train_id BIGINT,
        @travel_class NVARCHAR(10),
        @seats_booked INT
    )
    RETURNS DECIMAL(10,2)
    AS
    BEGIN
        DECLARE @fare DECIMAL(10,2)
        
        SELECT @fare = CASE @travel_class
            WHEN 'AC1' THEN fare_ac_first
            WHEN 'AC2' THEN fare_ac_second
            WHEN 'AC3' THEN fare_ac_third
            WHEN 'SLEEPER' THEN fare_sleeper
            ELSE 0
        END * @seats_booked
        FROM trains
        WHERE train_id = @train_id
        
        RETURN @fare
    END
END
GO 