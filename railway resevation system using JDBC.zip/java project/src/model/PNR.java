package model;

import java.sql.Timestamp;

public class PNR {
    private String pnrNumber;
    private int reservationId;
    private String status;
    private String coachNumber;
    private String seatNumbers;
    private Timestamp issuedAt;

    public PNR() {}

    public PNR(String pnrNumber, int reservationId, String status, String coachNumber, String seatNumbers, Timestamp issuedAt) {
        this.pnrNumber = pnrNumber;
        this.reservationId = reservationId;
        this.status = status;
        this.coachNumber = coachNumber;
        this.seatNumbers = seatNumbers;
        this.issuedAt = issuedAt;
    }

    // Getters and setters
    public String getPnrNumber() { return pnrNumber; }
    public void setPnrNumber(String pnrNumber) { this.pnrNumber = pnrNumber; }
    public int getReservationId() { return reservationId; }
    public void setReservationId(int reservationId) { this.reservationId = reservationId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getCoachNumber() { return coachNumber; }
    public void setCoachNumber(String coachNumber) { this.coachNumber = coachNumber; }
    public String getSeatNumbers() { return seatNumbers; }
    public void setSeatNumbers(String seatNumbers) { this.seatNumbers = seatNumbers; }
    public Timestamp getIssuedAt() { return issuedAt; }
    public void setIssuedAt(Timestamp issuedAt) { this.issuedAt = issuedAt; }
} 