package model;

import java.sql.Date;
import java.sql.Timestamp;

public class Reservation {
    private int reservationId;
    private int userId;
    private int trainId;
    private Date journeyDate;
    private String travelClass;
    private int seatsBooked;
    private Timestamp bookingTimestamp;
    private double totalAmount;

    public Reservation() {}

    public Reservation(int reservationId, int userId, int trainId, Date journeyDate, String travelClass, int seatsBooked, Timestamp bookingTimestamp, double totalAmount) {
        this.reservationId = reservationId;
        this.userId = userId;
        this.trainId = trainId;
        this.journeyDate = journeyDate;
        this.travelClass = travelClass;
        this.seatsBooked = seatsBooked;
        this.bookingTimestamp = bookingTimestamp;
        this.totalAmount = totalAmount;
    }

    // Getters and setters
    public int getReservationId() { return reservationId; }
    public void setReservationId(int reservationId) { this.reservationId = reservationId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getTrainId() { return trainId; }
    public void setTrainId(int trainId) { this.trainId = trainId; }
    public Date getJourneyDate() { return journeyDate; }
    public void setJourneyDate(Date journeyDate) { this.journeyDate = journeyDate; }
    public String getTravelClass() { return travelClass; }
    public void setTravelClass(String travelClass) { this.travelClass = travelClass; }
    public int getSeatsBooked() { return seatsBooked; }
    public void setSeatsBooked(int seatsBooked) { this.seatsBooked = seatsBooked; }
    public Timestamp getBookingTimestamp() { return bookingTimestamp; }
    public void setBookingTimestamp(Timestamp bookingTimestamp) { this.bookingTimestamp = bookingTimestamp; }
    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
} 