package model;

import java.sql.Date;
import java.sql.Time;

public class Train {
    private int trainId;
    private String trainName;
    private int totalSeats;
    private String boardingStation;
    private String destinationStation;
    private double fareAcFirst;
    private double fareAcSecond;
    private double fareAcThird;
    private double fareSleeper;
    private Date journeyDate;
    private Time departureTime;
    private Time arrivalTime;

    public Train() {}

    public Train(int trainId, String trainName, int totalSeats, String boardingStation, String destinationStation, double fareAcFirst, double fareAcSecond, double fareAcThird, double fareSleeper, Date journeyDate, Time departureTime, Time arrivalTime) {
        this.trainId = trainId;
        this.trainName = trainName;
        this.totalSeats = totalSeats;
        this.boardingStation = boardingStation;
        this.destinationStation = destinationStation;
        this.fareAcFirst = fareAcFirst;
        this.fareAcSecond = fareAcSecond;
        this.fareAcThird = fareAcThird;
        this.fareSleeper = fareSleeper;
        this.journeyDate = journeyDate;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
    }

    // Getters and setters
    public int getTrainId() { return trainId; }
    public void setTrainId(int trainId) { this.trainId = trainId; }
    public String getTrainName() { return trainName; }
    public void setTrainName(String trainName) { this.trainName = trainName; }
    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }
    public String getBoardingStation() { return boardingStation; }
    public void setBoardingStation(String boardingStation) { this.boardingStation = boardingStation; }
    public String getDestinationStation() { return destinationStation; }
    public void setDestinationStation(String destinationStation) { this.destinationStation = destinationStation; }
    public double getFareAcFirst() { return fareAcFirst; }
    public void setFareAcFirst(double fareAcFirst) { this.fareAcFirst = fareAcFirst; }
    public double getFareAcSecond() { return fareAcSecond; }
    public void setFareAcSecond(double fareAcSecond) { this.fareAcSecond = fareAcSecond; }
    public double getFareAcThird() { return fareAcThird; }
    public void setFareAcThird(double fareAcThird) { this.fareAcThird = fareAcThird; }
    public double getFareSleeper() { return fareSleeper; }
    public void setFareSleeper(double fareSleeper) { this.fareSleeper = fareSleeper; }
    public Date getJourneyDate() { return journeyDate; }
    public void setJourneyDate(Date journeyDate) { this.journeyDate = journeyDate; }
    public Time getDepartureTime() { return departureTime; }
    public void setDepartureTime(Time departureTime) { this.departureTime = departureTime; }
    public Time getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(Time arrivalTime) { this.arrivalTime = arrivalTime; }
} 